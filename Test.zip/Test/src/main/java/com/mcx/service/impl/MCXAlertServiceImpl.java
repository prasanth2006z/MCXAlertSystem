package com.mcx.service.impl;

import com.mcx.constants.NotificationConstants;
import com.mcx.model.AlertSystem;
import com.mcx.model.Notification;
import com.mcx.model.User;
import com.mcx.service.EmailNotificationServer;
import com.mcx.service.FCMServer;
import com.mcx.service.MCXAlertService;
import com.mcx.util.AlertUtil;
import com.mcx.util.YAMLConfig;
import okhttp3.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by prasanth.p on 06/05/18.
 */
public class MCXAlertServiceImpl implements MCXAlertService {

  private static final Logger logger = LogManager.getLogger(MCXAlertServiceImpl.class);

  @Autowired
  AlertSystem alertSystem;

  @Autowired
  EmailNotificationServer emailNotificationServer;

  @Autowired
  AlertUtil alertUtil;

  /**
   *
   * @param userName
   * @param password
   * @return
   */
  public String registerUser(String userName, String password) {
    logger.debug("User Registration started for user:" + userName);
    if (alertUtil.validateUser(userName, password) && alertUtil.getUserByUserNameAndPassword(userName, password) == null) {
      int size = (alertSystem.getUserMap().size() + 1);
      alertSystem.getUserMap().put(size, alertUtil.constructUser(userName, password));
      emailNotificationServer.sedEmail(alertSystem.getUserMap());
      return NotificationConstants.SUCCESS;
    }
    return NotificationConstants.REGISTER_USER_ERROR;
  }

  /**
   *
   * @param userName
   * @param password
   * @return
   */
  public Map<String, String> login(String userName, String password) {
    logger.debug("User login: username " + userName);
    Map<String, String> map = new HashMap<>();
    if (alertUtil.validateUser(userName, password)) {
      User user = alertUtil.createUUID(userName, password);
      if (user != null) {
        map.put("status", NotificationConstants.SUCCESS);
        map.put("token", user.getAuthorization());
        map.put("priority", user.getRole());
        alertSystem.getLoginMap().put(user.getAuthorization(), null);
      }
    } else {
      logger.debug("User login failed!!!: username " + userName + "password:" + password);
      map.put("status", NotificationConstants.USER_LOGIN_ERROR_STATUS);
      map.put("Error Message", NotificationConstants.USER_LOGIN_ERROR);
    }
    return map;
  }

  /**
   *
   * @param authn
   * @param token
   * @return
   */
  public String registerDevice(String authn, String token) {
    if (alertUtil.validateAuthn(authn)) {
      alertSystem.getLoginMap().put(authn, token);
      return NotificationConstants.DEVICE_REGISTRATION_SUCCESS;
    }
    return NotificationConstants.INVALID_AUTHENTICATION;
  }

  /**
   *
   * @param notification
   * @param authn
   * @return
   */
  public String writeNotifications(Notification notification, String authn) {
    if (alertUtil.validateAuthn(authn)) {
      String message = alertUtil.validate(notification);
      if (message.equals(NotificationConstants.SUCCESS)) {
        String token = alertSystem.getLoginMap().get(authn);
        message = alertUtil.sendNotifications(notification, token);
      }
      return message;
    }
    return NotificationConstants.INVALID_AUTHENTICATION;
  }

  /**
   *
   * @param authn
   * @return
   */
  public String logout(String authn) {
    if (alertSystem.getLoginMap() != null && alertSystem.getLoginMap().size() > 0 && alertSystem.getLoginMap().containsKey(authn)) {
      alertSystem.getLoginMap().remove(authn);
      return NotificationConstants.USER_LOGOUT_SUCCESS;
    } else {
      return NotificationConstants.USER_LOGOUT_ERROR_STATUS;
    }
  }

}
