package com.mcx.util;

import com.mcx.constants.NotificationConstants;
import com.mcx.model.AlertSystem;
import com.mcx.model.Notification;
import com.mcx.model.User;
import com.mcx.service.EmailNotificationServer;
import com.mcx.service.FCMServer;
import com.mcx.service.impl.MCXAlertServiceImpl;
import okhttp3.Response;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.UUID;

/**
 * @Author: pxp167
 * @Date: 5/8/2018
 *
 */
public class AlertUtil {

  private static final Logger logger = LogManager.getLogger(AlertUtil.class);

  @Autowired
  AlertSystem alertSystem;

  @Autowired
  FCMServer fcmServer;

  @Autowired
  EmailNotificationServer emailNotificationServer;

  @Autowired
  private YAMLConfig myConfig;

  public String sendNotifications(Notification notification, String token) {
    Response response = fcmServer.sendFCMNotification(notification, token);
    logger.debug("Push response: " + response);
    if (response!=null && response.isSuccessful()) {
      emailNotificationServer.sedEmail(buildMessage(notification));
      return NotificationConstants.SUCCESS;
    } else {
      return NotificationConstants.USER_FCM_ERROR;
    }

  }

  public boolean validateAuthn(String auth) {
    logger.debug("Validate authn:" + auth);
    if (alertSystem.getLoginMap() != null && alertSystem.getLoginMap().size() > 0) {
      logger.debug("Logged-In user size:" + alertSystem.getLoginMap().size());
      if (alertSystem.getLoginMap().containsKey(auth)) {
        return true;
      }
      return false;
    } else {
      logger.debug("No user LoggedIn yet!!!");
      return false;
    }
  }

  public User constructUser(String userName, String password) {
    User user = new User();
    user.setUserId(userName);
    user.setUserName(userName);
    user.setPassword(password);
    user.setRole(getUserRole(userName, password));
    user.setDate(new Date());
    return user;
  }

  public String getUserRole(String userName, String password) {
    if (userName.equals(myConfig.getName()) && password.equals(myConfig.getValue())) {
      return "Admin";
    } else {
      return "user";
    }
  }

  public boolean validateUser(String userName, String password) {
    if (userName != null && password != null) {
      return true;
    }
    return false;
  }

  public User getUserByUserNameAndPassword(String userName, String password) {
    logger.debug("Search user by username and password starts");
    if (userName != null && password != null) {
      if (alertSystem.getUserMap() != null && alertSystem.getUserMap().size() > 0) {
        for (Integer key : alertSystem.getUserMap().keySet()) {
          User user = alertSystem.getUserMap().get(key);
          if (user != null) {
            if (userName.equals(user.getUserName()) && password.equals(user.getPassword())) {
              logger.debug("User Exist with username as: " + userName);
              return user;
            }
          } else {
            logger.debug("Invalid User : userName:" + userName + ", password:" + password);
          }
        }
      }
      logger.debug("Search user by username and password End");
      return null;
    }
    logger.debug("Search user by username and password End");
    return null;
  }

  public User getUserByAuthorization(String authn) {
    logger.debug("Search user by authorization starts");
    if (authn != null) {
      if (alertSystem.getUserMap() != null && alertSystem.getUserMap().size() > 0) {
        for (Integer key : alertSystem.getUserMap().keySet()) {
          User user = alertSystem.getUserMap().get(key);
          if (user != null) {
            if (authn.equals(user.getAuthorization())) {
              logger.debug("Search success: User Exist with username: " + user.getUserName());
              return user;
            }
          } else {
            logger.debug("Invalid User authn: " + authn);
          }
        }
      }
    }
    logger.debug("Search user by authorization End");
    return null;
  }

  public User createUUID(String userName, String password) {
    User user = getUserByUserNameAndPassword(userName, password);
    if (user != null) {
      String authn = UUID.randomUUID().toString();
      user.setAuthorization(authn);
      return user;
    }
    return null;
  }

  public String validate(Notification notification) {
    String message = NotificationConstants.SUCCESS;
    if (notification != null) {
      if (StringUtils.isEmpty(notification.getType())) {
        message = NotificationConstants.BUY_SELL_ERROR;
        return message;
      }
      if (StringUtils.isEmpty(notification.getName())) {
        message = NotificationConstants.COMMODITY_ERROR;
        return message;
      }
      if (StringUtils.isEmpty(notification.getBET())) {
        message = NotificationConstants.BET_ERROR;
        return message;
      }
      if (StringUtils.isEmpty(notification.getStopLoss())) {
        message = NotificationConstants.SL_ERROR;
        return message;
      }
      if (StringUtils.isEmpty(notification.getTGT())) {
        message = NotificationConstants.TGT_ERROR;
        return message;
      }
    } else {
      message = NotificationConstants.REQUEST_ERROR;
      return message;
    }
    return message;
  }

  public String buildMessage(Notification notification){
    String msg="";
    if(notification!=null){
      msg=notification.getType()+" "+notification.getName()+" "+ notification.getBET()+" "+notification.getPeriod()+" "+notification.getStopLoss()+
        " "+notification.getTGT();
    }
    return msg;
  }

}
